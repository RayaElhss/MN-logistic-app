module.exports = {
  content: [
      "./index.html",
      "./src/**/*.{js,ts,jsx,tsx}", // Includes all Vite files
  ],
  theme: {
      extend: {}, // Add customizations if needed
  },
  plugins: [], // Add plugins if necessary (e.g., forms or typography)
};
