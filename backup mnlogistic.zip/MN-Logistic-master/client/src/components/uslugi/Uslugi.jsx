import "aos/dist/aos.css"; // Ensure AOS styles are imported
import AOS from "aos"; // Import AOS
import { useEffect } from "react";
import UslugiCards from "./UslugiCards";
import styles from "./Uslugi.module.css"; // Import the module CSS

export default function ExploreTour() {
    useEffect(() => {
        AOS.init({ duration: 1000 }); // Set duration for animations
    }, []);

    return (
        <div id="uslugi" className={`container-fluid ${styles.ExploreTour} py-5`}>
            <div className="container py-5">
                {/* Title Section */}
                <div className={`text-center mb-5 ${styles["title-section"]}`} data-aos="fade-bottom">
                    <h2 className={styles.title}>ВНОСНО ОБМИТЯВАНЕ НА СТОКИ С МН ЛОДЖИСТИК</h2>
                    <p className={styles.subtitle}>
                        Вашият доверен партньор за митническо обслужване и международна търговия
                    </p>
                </div>

                {/* Content Section */}
                <div className="row">
                    <div className="col-12 mb-4">
                        <div className={styles.textContainer} data-aos="fade-up">
                            <h3>Какво включва митническото обслужване:</h3>
                            <ul className={styles.bulletPoints}>
                                <li>Подготовка на документация</li>
                                <li>Бързо освобождаване на стоки</li>
                                <li>Митническа оценка</li>
                            </ul>
                            <p>
                                Вносът на стоки не е просто част от международната търговия – той е двигател на растежа и успеха на
                                вашия бизнес в България и Европейския съюз. България, като стратегическа входна точка към
                                европейския пазар, предлага неограничени възможности, но и предизвикателства, свързани със
                                сложните митнически процедури.
                            </p>
                        </div>
                    </div>

                    <div className="col-12 mb-4">
                        <div className={styles.textContainer} data-aos="fade-up">
                            <h3>Ефективно управление на процеса</h3>
                            <p>
                                Нашият екип осигурява ефективно управление на процесите с внимание към детайлите – правилно и
                                навременно подготвена документация, гъвкави решения и постоянен контрол на всяка стъпка.
                            </p>
                        </div>
                    </div>

                    <div className="col-12 mb-4">
                        <div className={styles.textContainer} data-aos="fade-up">
                            <h3>Защо да изберете нас?</h3>
                            <ul className={styles.bulletPoints}>
                                <li>Надеждно и бързо митническо освобождаване</li>
                                <li>Дългосрочни партньорства и доверие</li>
                                <li>Експертно познаване на регулациите и процедурите</li>
                                <li>Лично отношение и високо качество на услугите</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <UslugiCards />
            </div>
        </div>
    );
}
