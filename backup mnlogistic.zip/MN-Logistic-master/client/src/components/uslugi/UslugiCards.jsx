import React from "react";
import { Link } from "react-router-dom";

export default function UslugiCards() {
    const uslugiData = [
        {
            path: "/vnosno-obmitqvane",
            name: "Вносно обмитяване",
            imageUrl: "https://ourstar.org.uk/wp-content/uploads/2023/06/europe-flag-1100x733-1-1024x682.jpg",
            logoUrl: "/img/arrow-right.png",
        },
        {
            path: "/iznosno-obmitqvane",
            name: "Износно обмитяване",
            imageUrl: "https://webnews.bg/uploads/images/78/5978/365978/768x432.jpg?_=1530524143",
            logoUrl: "/img/arrow-right.png",
        },
        {
            path: "/tranzitno-obmitqvane",
            name: "Транзитно обмитяване",
            imageUrl: "https://archiwumdepozytowe.pl/images/design/podstrona-img-wniosek.webp",
            logoUrl: "/img/arrow-right.png",
        },
    ];

    return (
        <div className="row">
            {uslugiData.map((service) => (
                <div className="col-md-4 mb-4" key={service.path}>
                    <Link
                        to={service.path}
                        className="card tour-card"
                        onClick={() => window.scrollTo(0, 0)}
                        style={{ textDecoration: "none", cursor: "pointer" }}
                    >
                        <img
                            className="card-img-top"
                            src={service.imageUrl}
                            alt="Card image cap"
                        />
                        <div className="card-body d-flex align-items-center">
                            <img
                                src={service.logoUrl}
                                alt="Logo"
                                className="card-logo me-3"
                                style={{ width: "50px", height: "40px" }}
                            />
                            <div className="text-container">
                                <h5 className="card-title mb-0">{service.name}</h5>
                            </div>
                        </div>
                    </Link>
                </div>
            ))}
        </div>
    );
}
