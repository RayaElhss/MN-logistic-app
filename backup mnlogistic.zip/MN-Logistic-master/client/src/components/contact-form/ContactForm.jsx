import React, { useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import styles from './ContactForm.module.css';

const ContactForm = () => {
    const [successMessage, setSuccessMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false); // State for spinner
    const form = useRef();

    const handleSubmit = (e) => {
        e.preventDefault();
        setIsLoading(true); // Show spinner when sending starts

        const formData = new FormData(form.current);
        const fromName = formData.get('from_name');
        const replyTo = formData.get('reply_to');
        const phoneNumber = formData.get('phone_number');
        const message = formData.get('message');

        // Validation Regex
        const nameRegex = /^.{4,15}$/; // Name between 4 and 15 characters
        const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/; // Only Gmail addresses
        const phoneRegex = /^[0-9+\-\s]{4,}$/; // At least 4 characters, allowing digits, +, -, and spaces
        const messageRegex = /^.{4,}$/; // Message must have at least 4 characters

        // Validation Checks
        if (!nameRegex.test(fromName)) {
            alert('Името трябва да съдържа между 4 и 15 символа.');
            return;
        }
        if (!gmailRegex.test(replyTo)) {
            alert('Моля, въведете валиден Gmail адрес.');
            return;
        }
        if (!phoneRegex.test(phoneNumber)) {
            alert('Телефонният номер трябва да съдържа поне 4 символа и да е валиден.');
            return;
        }
        if (!messageRegex.test(message)) {
            alert('Съобщението трябва да съдържа поне 4 символа.');
            return;
        }

        // Send form data to EmailJS
        emailjs
            .sendForm('service_h2oe1zq', 'template_112fahw', form.current, 'ovM5E9QlfQ0mfrWDf')
            .then(
                (result) => {
                    setIsLoading(false); // Hide spinner
                    setSuccessMessage('Благодарим ви, че се свързахте с нас!');
                    form.current.reset(); // Reset the form
                },
                (error) => {
                    setIsLoading(false); // Hide spinner
                    console.error('Email send failed:', error.text);
                }
            );
    };

    return (
        <section
            className={styles.sectionBg}
            style={{ backgroundImage: 'url(https://zn.ua/img/article/5751/78_main-v1703081735.jpg)' }}
            data-scroll-index="7"
        >
            <div className={styles.overlay}>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 d-flex align-items-center">
                            <div className={styles.contactInfo}>
                                <h2 className={styles.contactTitle} style={{ color: 'black' }}>Имате Въпроси?</h2>
                                <p style={{ color: 'white' }}>
                                    Ако имате въпроси или се нуждаете от повече информация за нашите услуги, не се колебайте да се свържете с нас. Ние сме тук, за да помогнем и да ви предоставим нужната подкрепа.
                                </p>

                                <ul className={styles.contactInfoList}>
                                    <li>
                                        <div className={styles.infoLeft}>
                                            <i className="fas fa-mobile-alt"></i>
                                        </div>
                                        <div className={styles.infoRight}>
                                            <h4>+359 897089094</h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div className={styles.infoLeft}>
                                            <i className="fas fa-at"></i>
                                        </div>
                                        <div className={styles.infoRight}>
                                            <h4>info@mnlogistic.bg</h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div className={styles.infoLeft}>
                                            <i className="fas fa-map-marker-alt"></i>
                                        </div>
                                        <div className={styles.infoRight}>
                                            <h4>София, Света Троица, бл. 168</h4>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div className="col-lg-6 d-flex align-items-center">
                            <div className={styles.contactForm}>
                                <form ref={form} onSubmit={handleSubmit}>
                                    <div className="row">
                                        <div className="col-md-12">
                                            <div className={styles.formGroup}>
                                                <input
                                                    type="text"
                                                    name="from_name"
                                                    className={styles.formControl}
                                                    placeholder="Вашето име *"
                                                    required
                                                    minLength="4"
                                                    maxLength="15"
                                                    title="Името трябва да съдържа между 4 и 15 символа."
                                                />
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <div className={styles.formGroup}>
                                                <input
                                                    type="email"
                                                    name="reply_to"
                                                    className={styles.formControl}
                                                    placeholder="Вашия Gmail адрес *"
                                                    required
                                                    pattern="[a-zA-Z0-9._%+-]+@gmail\.com"
                                                    title="Моля, въведете валиден Gmail адрес."
                                                />
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <div className={styles.formGroup}>
                                                <input
                                                    type="tel"
                                                    name="phone_number"
                                                    className={styles.formControl}
                                                    placeholder="Вашият телефонен номер *"
                                                    required
                                                    pattern="[0-9+\-\s]{4,}"
                                                    title="Телефонният номер трябва да съдържа поне 4 символа."
                                                />
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <div className={styles.formGroup}>
                                                <textarea
                                                    rows="4"
                                                    name="message"
                                                    className={styles.formControl}
                                                    placeholder="Питайте ни! *"
                                                    required
                                                    minLength="4"
                                                    title="Съобщението трябва да съдържа поне 4 символа."
                                                ></textarea>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                        <button
                                        className={`${styles.btn} ${styles.btnBig}`}
                                        type="submit"
                                        disabled={isLoading} // Disable button while loading
                                    >
                                        {isLoading ? 'Изпращане...' : 'Изпрати'}
                                        {isLoading && (
                                            <span className={styles.spinner}></span> // Add spinner
                                        )}
                                    </button>
                                        </div>
                                    </div>
                                    {successMessage && <p className={styles.successMessage}>{successMessage}</p>}
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ContactForm;
