import Copyright from "./Copyright";
import styles from './Footer.module.css';

export default function Footer() {
    return (
        <>

            <div className={`container-fluid ${styles.footer} py-5`}>
                <div className="container py-5">
                    <div className="row g-5">
                        <div className="col-md-6 col-lg-6 col-xl-3">
                            <div className={`${styles.footerItem} d-flex flex-column`}>
                                <h4 className="mb-4 text-white">
                                    Свържете се с нас:
                                </h4>
                                <a
                                    href="https://www.google.com/maps/place/София,+Света+Троица,+бл.+168,+вход+Г/"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <i className="fas fa-home me-2" />
                                    Света Троица, бл. 168, вход Г.
                                </a>

                                <a href="mailto:info@mnlogistic.bg">
                                    <i className="fas fa-envelope me-2" />
                                    {' '}info@mnlogistic.bg
                                </a>
                                <a href="tel:+359897089094">
                                    <i className="fas fa-phone me-2" />
                                    {' '}+359897089094
                                </a>


                            </div>
                        </div>
                        <div className="col-md-6 col-lg-6 col-xl-3">
                            <div className={`${styles.footerItem} d-flex flex-column`}>
                                <h4 className="mb-4 text-white">
                                    MN Logistic
                                </h4>
                                <a href="/transport">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Транспорт
                                </a>

                                <a href="/blog">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Блог
                                </a>

                                <a href="/contacts">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Контакти
                                </a>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-6 col-xl-3">
                            <div className={`${styles.footerItem} d-flex flex-column`}>
                                <h4 className="mb-4 text-white">
                                    Услуги
                                </h4>
                                <a href="/vnosno-obmitqvane">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Вносно обмитяване на стоки
                                </a>
                                <a href="/iznosno-obmitqvane">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Износно обмитяване на стоки
                                </a>
                                <a href="/tranzitno-obmitqvane">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Изготвяне на транзитен документ Т1
                                </a>
                                <a href="/privacy">
                                    <i className="fas fa-angle-right me-2" />
                                    {' '}Политика за поверителност
                                </a>

                            </div>
                        </div>
                        <div className="col-md-6 col-lg-6 col-xl-3">
                            <div className={`${styles.footerItem}`}>
                                <div className="row gy-3 gx-2 mb-4">

                                </div>
                                <h4 className="text-white mb-3">
                                    Работно време:
                                </h4>
                                <h3 style={{ color: 'lightgreen' }}>24/7</h3>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Copyright />
        </>
    );
}