import React from 'react';
import styles from './CallButton.module.css';

const CallButton = () => {
  return (
    <a href="tel:+359897089094" className={styles.callButton}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="currentColor"
        width="24px"
        height="24px"
        className={styles.callIcon}
      >
        <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2a1.5 1.5 0 011.65-.33c1.12.45 2.34.68 3.59.68a1.5 1.5 0 011.5 1.5v3.75a1.5 1.5 0 01-1.5 1.5A18.485 18.485 0 012 4.5a1.5 1.5 0 011.5-1.5H7.25a1.5 1.5 0 011.5 1.5c0 1.25.23 2.47.68 3.59a1.5 1.5 0 01-.33 1.65l-2.2 2.2z" />
      </svg>
    </a>
  );
};

export default CallButton;
