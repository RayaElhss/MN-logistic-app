import React from 'react';
import { useLocation } from 'react-router-dom';

export default function HeroSection() {
    const location = useLocation();

    // Match content based on the path
    const services = {
        '/vnosno-obmitqvane': {
            title: 'Вносно обмитяване на стоки',
            description: 'Ускорете растежа на вашия бизнес с нашите услуги за вносно обмитяване.',
            image: 'https://www.importbox.net/storage/2020/04/favicon-1.png',
        },
        '/iznosno-obmitqvane': {
            title: 'Износно обмитяване на стоки',
            description: 'Нека вашите стоки достигнат световните пазари с лекота.',
            image: 'https://via.placeholder.com/600x450', // Replace with a relevant image
        },
        '/tranzitno-obmitqvane': {
            title: 'Транзитно обмитяване на стоки',
            description: 'Гарантираме бърз транзит и обработка на вашите стоки.',
            image: 'https://via.placeholder.com/600x450', // Replace with a relevant image
        },
    };

    const service = services[location.pathname] || {
        title: 'Услуга не е намерена',
        description: 'Моля, изберете валидна услуга.',
        image: 'https://via.placeholder.com/600x450',
    };

    return (
        <div className="hero-section">
            {/* Background image and title section */}
            <div className="hero-banner">
                <div className="hero-content">
                    <h1 className="hero-title">{service.title}</h1>
                </div>
            </div>

            {/* Content section */}
            <div className="hero-description">
                <div className="description-left">
                    <h2>{service.title} с МН ЛОДЖИСТИК:</h2>
                    <p>{service.description}</p>

                    {/* Add the image below the subtitle */}
                    <img
                        src={service.image}
                        alt="Service"
                        style={{
                            width: '100%',
                            maxWidth: '600px',
                            height: '450px',
                            margin: '20px 0',
                            borderRadius: '10px',
                            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                        }}
                    />
                </div>
                <div className="description-right">
                    <p>
                        Вносът на стоки е не просто етап от международната търговия – това е ключът към успеха на вашия бизнес в България и в рамките на Европейския съюз...
                    </p>
                </div>
            </div>
        </div>
    );
}
