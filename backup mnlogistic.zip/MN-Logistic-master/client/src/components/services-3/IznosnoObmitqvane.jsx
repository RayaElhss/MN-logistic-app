export default function IznosnoObmitqvane() {
    return (
        <div className="hero-section">
            <div className="hero-banner">
                <div className="hero-content">
                    <h1 className="hero-title">Вносно обмитяване на стоки</h1>
                </div>
            </div>
            <div className="hero-description">
                <div className="description-content">
                    <h2 className="hero-title1">Вносно обмитяване на стоки с МН ЛОДЖИСТИК:</h2>
                    <ul>
                        <li>Подготовка на документация</li>
                        <li>Бързо освобождаване на стоки</li>
                        <li>Митническа оценка</li>
                    </ul>
                    <hr style={{ width: "100%", border: "2px solid red", margin: "40px auto" }} />
                    <p className="custom-paragraph">
                        Вносът на стоки не е просто част от международната търговия – той е двигател на растежа и успеха на вашия бизнес в България и Европейския съюз. България, като стратегическа входна точка към европейския пазар, предлага неограничени възможности, но и предизвикателства, свързани със сложните митнически процедури.
                    </p>
                    <p className="custom-paragraph">
                        Ефективното управление на тези процеси започва с внимание към детайлите – правилно изготвени фактури, точни товарителници и, ако се изисква, сертификати или разрешителни. Това е ключът към гладкото преминаване на вашите стоки през митниците и тяхното навременно освобождаване.
                    </p>
                    <ul style={{ listStyle: "none", padding: 0 }}>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> <strong style={{ fontSize: "30px" }}>Митническите регулации:</strong> Основата на успешния внос. Декларацията на всяка стока и правилното изчисляване на нейната митническа стойност са задължителни.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> <strong style={{ fontSize: "30px" }}>Рискове:</strong> Неспазването на изискванията може да доведе до закъснения, санкции и усложнения, които ще затруднят бизнеса ви.
                        </li>
                    </ul>
                    <h3 style={{ textAlign: "left", fontSize: "40px", marginTop: "40px", fontWeight: "bold", paddingBottom: "40px" }}>Как МН ЛОДЖИСТИК може да бъде вашият доверен партньор?</h3>
                    <p className="custom-paragraph" style={{ textAlign: "left" }}>
                        Нашият екип от експерти е тук, за да направи вносният процес безпроблемен и ефективен. Ние предлагаме:
                    </p>
                    <ul style={{ listStyle: "none", padding: 0, textAlign: "left" }}>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Професионално съдействие във всяка стъпка – от подготовка на документация до окончателното освобождаване на стоките.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Персонализирани решения според нуждите на вашия бизнес.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Сигурност и спокойствие, че всичко е съобразено със закона.
                        </li>
                    </ul>
                    <p style={{ fontSize: "28px", color: " dark blue" }}>
                        С МН ЛОДЖИСТИК зад гърба ви, вашият бизнес ще се фокусира върху растежа, докато ние се грижим за сложностите на митническите процедури. Доверете ни се – успехът започва от тук!
                    </p>
                </div>
            </div>
        </div>
    );
}


