import React from "react";

export default function VnosnoObmitqvane() {
    return (
        <div className="hero-section">
            <div className="hero-banner">
                <div className="hero-content">
                    <h1 className="hero-title">Износно обмитяване на стоки</h1>
                </div>
            </div>
            <div className="hero-description">
                <div className="description-content">
                    <h2 className="hero-title1">Износно обмитяване с МН ЛОДЖИСТИК:</h2>
                    <ul>
                        <li>Подготовка на документация</li>
                        <li>Гладко преминаване през митниците</li>
                        <li>Организиране на транспорта</li>
                    </ul>
                    <hr style={{ width: "100%", border: "2px solid red", margin: "40px auto" }} />
                    <p className="custom-paragraph">
                        Износът на стоки е ключов аспект на международната търговия и представлява възможност за предприятия, които искат да разширят своето присъствие на глобалния пазар. Важно е да знаете, че износът от България изисква спазване на специфични процедури и регулации, за да се осигури безпроблемно преминаване на стоките през митниците и успешна доставка до крайните клиенти.
                    </p>
                    <ul style={{ listStyle: "disc", paddingLeft: "20px", margin: "20px 0" }}>
                        <li>Търговска фактура</li>
                        <li>Товарителница</li>
                        <li>Сертификат за произход (при нужда)</li>
                    </ul>
                    <p className="custom-paragraph">
                        Правилното съставяне на тези документи е от изключителна важност, тъй като неточности могат да доведат до забавяния или дори санкции.
                    </p>
                    <h3 style={{ textAlign: "left", fontSize: "40px", marginTop: "40px", fontWeight: "bold", paddingBottom: "20px" }}>Как МН ЛОДЖИСТИК може да ви помогне?</h3>
                    <ul style={{ listStyle: "none", padding: 0, textAlign: "left" }}>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Професионална помощ за планиране и подготовка на документация.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Експертни съвети относно спецификата на документите и техните изисквания.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Комуникация с митниците и гладко подаване на митническата декларация.
                        </li>
                        <li style={{ marginBottom: "20px" }}>
                            <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Организиране на транспорта след успешно освобождаване на стоките.
                        </li>
                    </ul>
                    <p className="custom-paragraph">
                        Ние от МН ЛОДЖИСТИК се ангажираме да ви предоставим качествени услуги, които ще улеснят целия процес и ще ви спестят време и усилия. За повече информация относно процедурата по износ на стоки, моля, свържете се с нас.
                    </p>
                </div>
            </div>
        </div>
    );
}
