import React from "react";

export default function TranzitnoObmitqvane() {
    return (
        <div className="hero-section">
        <div className="hero-banner">
            <div className="hero-content">
                <h1 className="hero-title">Изготвяне на транзитен документ T1</h1>
            </div>
        </div>
        <div className="hero-description">
            <div className="description-content">
                <h2 className="hero-title1">Транзитен режим с МН ЛОДЖИСТИК:</h2>
                <ul>
                    <li>Улеснено преминаване на стоки през границите</li>
                    <li>Изготвяне на документи по процедура Т1</li>
                    <li>Експертно съдействие при митнически формалности</li>
                </ul>
                <hr style={{ width: "100%", border: "2px solid red", margin: "40px auto" }} />
                <p className="custom-paragraph">
                    Режимът на транзит е важен аспект от митническите процедури, който позволява пренасянето на стоки от едно място на митническата територия на Европейския съюз (ЕС) до друго. Този режим е особено важен за бизнеса, занимаващ се с международна търговия, тъй като осигурява плавно и безпроблемно преминаване на стоки през границите.
                </p>
                <h3 style={{ textAlign: "left", fontSize: "40px", marginTop: "40px", fontWeight: "bold", paddingBottom: "20px" }}>Видове транзит:</h3>
                <ul style={{ listStyle: "disc", paddingLeft: "20px", margin: "20px 0" }}>
                    <li>
                        <strong>Външен Общностен Транзит (Процедура Т1):</strong> Прилага се при пренасянето на стоки, които не принадлежат на Европейския съюз (необщностни стоки).
                    </li>
                    <li>
                        Този режим позволява транспортиране на стоки без да се заплащат вносни митни такси в момента на преминаване на границите. Вместо това, митата се заплащат, когато стоките достигнат до крайния си получател.
                    </li>
                    <li>
                        Стоките не подлежат на мерките на търговската политика, докато са в режим Т1.
                    </li>
                </ul>
                <h3 style={{ textAlign: "left", fontSize: "40px", marginTop: "40px", fontWeight: "bold", paddingBottom: "20px" }}>Как МН ЛОДЖИСТИК може да ви помогне?</h3>
                <ul style={{ listStyle: "none", padding: 0, textAlign: "left" }}>
                    <li style={{ marginBottom: "20px" }}>
                        <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Изготвяне на необходимата документация за транзитен режим Т1.
                    </li>
                    <li style={{ marginBottom: "20px" }}>
                        <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Експертни съвети относно изискванията на митническите органи.
                    </li>
                    <li style={{ marginBottom: "20px" }}>
                        <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Подготовка и подаване на декларацията за транзит.
                    </li>
                    <li style={{ marginBottom: "20px" }}>
                        <span style={{ color: "red", fontSize: "20px" }}>&#10095;</span> Гладка координация с митниците за безпроблемно транспортиране на стоките.
                    </li>
                </ul>
                <p className="custom-paragraph">
                    Ние от МН ЛОДЖИСТИК предлагаме професионална подкрепа и качествени услуги, които ще улеснят целия процес и ще гарантират успешното преминаване на стоките ви. За повече информация относно процедурата Т1, моля, свържете се с нас.
                </p>
            </div>
        </div>
    </div>
    );
}

