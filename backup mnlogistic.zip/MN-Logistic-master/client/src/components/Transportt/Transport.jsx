import React from 'react';
import styles from './Transport.module.css';
import TransportCards from './transportCards';

const Transport = () => {


  return (
    <div className={styles.container}>
      {/* Main content */}
      <h1 className={styles.title}>ТРАНСПОРТ</h1>


      <p className={styles.intro}>
        Ние сме екип със сериозен опит и задълбочено познаване на нормативната база. Ние сме гъвкави и креативни. Натрупаните знания и професионализъм ни позволяват да Ви предложим компетентно, коректно и качествено обслужване в най-кратки срокове.
      </p>

      <TransportCards />


      <section className={styles.section}>
        <h3 className={styles.heading}>Запитване за транспорт</h3>
        <p>
          Нека вашият товар пътува сигурно и навреме
          Търсите надеждно транспортно решение? Ние сме тук, за да предложим персонализирани услуги, съобразени с вашите нужди. Благодарение на нашата мрежа от доверени партньори, можем да организираме транспорт за всякакъв вид товари до всяка точка на света.

        </p>
        <p>
          Нашите предимства
          Гъвкави транспортни решения – Сухопътен, морски и въздушен транспорт.
          Достъпни цени – Възползвайте се от нашите конкурентни условия.
        </p>
      </section>

      {/* Card Section */}
      {/* <h2 className={styles.cardSectionTitle}>Demo 1</h2>

      <div className={styles.cardContainer}>
        {cards.map((card) => (
          <div key={card.id} className={styles.card} style={{ backgroundImage: `url(${card.imageUrl})` }}>
            <div className={styles.overlay}>
              <h3 className={styles.cardTitle}>{card.title}</h3>
              <p className={styles.cardDescription}>{card.description}</p>
            </div>
          </div>
        ))}
      </div> */}
    </div>
  );
};

export default Transport;
