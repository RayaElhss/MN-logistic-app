# ReactJS-Project
steps to start:
- navigate to the client folder
- run:
  - npm i
  - npm run dev.
